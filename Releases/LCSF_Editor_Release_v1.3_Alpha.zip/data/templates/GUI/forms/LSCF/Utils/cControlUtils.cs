﻿using System;
using System.Windows.Forms;

public class cControlUtils
{
	public cControlUtils()
	{
	}	
	public static void centerControl(Control container,Control host)
	{
		host.Left = (container.Width/2) - (host.Width/2);
		host.Top =  (container.Height/2) - (host.Height/2);
	}
}
