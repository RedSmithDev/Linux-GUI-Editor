﻿using System;

public class eCtlNames
{
	public static string Button 		= "Button";
	public static string Label 			= "Label";
	public static string TextInput 		= "TextInput";
	public static string ComboBox 		= "ComboBox";
	public static string ListBox 		= "ListBox";
	public static string PictureBox 	= "PictureBox";
	public static string CheckBox 		= "CheckBox";
	public static string RadioButton 	= "RadioButton";
	public static string ProgressBar 	= "ProgressBar";
	public static string ThreadedTimer	= "ThreadedTimer";
	public static string Panel 			= "Panel";
}
