﻿using System;
namespace LCSF_Utils
{
    public class cDebug
    {
        public cDebug()
        {
        }

        public static void Dummy(string _str)
        {

        }

        public static void Dummy(Exception _e)
        {

        }

    }
}
