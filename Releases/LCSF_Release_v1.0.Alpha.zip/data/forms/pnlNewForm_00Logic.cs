using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LSCFForms
{

    public partial class pnlNewForm_00 : Form
    {

		public pnlNewForm_00()
        {
            InitializeComponent();
        }

		private void Controls_Click(Control sender, efrmMainControls ctlName, EventArgs e)
		{
			switch(ctlName)
			{
			}
		}


		private void Controls_DoubleClick(Control sender, efrmMainControls ctlName, EventArgs e)
		{
			switch(ctlName)
			{
			}
		}


		private void Controls_KeyDown(Control sender, efrmMainControls ctlName, KeyEventArgs e)
		{
			switch(ctlName)
			{
				case efrmMainControls.txt0:
				{
				}
				break;
			}
		}


		private void Controls_Tick(Control sender, efrmMainControls ctlName, EventArgs e)
		{
			switch(ctlName)
			{
			}
		}


    }
}
