using System;
using System.Collections.Generic;
using System.Windows.Forms;
using LCSF_Editor;
using LCSF_Editor.CustomControls;

// EDITOR GENERATED CODE THIS FILE IS OVERRIDED , CUSTOM CODE RELATED TO CONTROLS , PUT in the "GUI/pnlXXXXLogic.cs"

namespace LSCFForms
{

partial class pnlRecentProjects

    {

		public enum efrmMainControls
		{
			pnlRecentProjects,
			lstProjecs,
			btnCreateProject,
			btnOpenProject,
			btnClose,
			btnBrowse,
			txtExistentProjectDir,
			COUNT
		};


		TextBox txtExistentProjectDir = new TextBox();
		Button btnBrowse = new Button();
		Button btnClose = new Button();
		Button btnOpenProject = new Button();
		Button btnCreateProject = new Button();
		ListBox lstProjecs = new ListBox();


		public List<string> memFormList = new List<string>();

        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private Dictionary<string, efrmMainControls> dCtlName = new Dictionary<string, efrmMainControls>();
        private Dictionary<string, Control> dCtls = new Dictionary<string, Control>();

        private void InitializeComponent()
        {
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pnlRecentProjects));


		memFormList.Add("[Panel]");
		memFormList.Add("Name:pnlRecentProjects");
		memFormList.Add("MaximizeBox:False");
		memFormList.Add("MinimizeBox:False");
		memFormList.Add("Size:731,462");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Recent Projects");
		memFormList.Add("[TextInput]");
		memFormList.Add("Name:txtExistentProjectDir");
		memFormList.Add("Position:10,10");
		memFormList.Add("Size:640,25");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Existent Project Dir");
		memFormList.Add("BorderStyle:FixedSingle");
		memFormList.Add("Multiline:False");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("TextType:Text");
		memFormList.Add("BorderStyle:Outlined");
		memFormList.Add("[Button]");
		memFormList.Add("Name:btnBrowse");
		memFormList.Add("Position:660,10");
		memFormList.Add("Size:51,25");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:..");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("[Button]");
		memFormList.Add("Name:btnClose");
		memFormList.Add("Position:10,390");
		memFormList.Add("Size:90,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:9.75");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Close");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("[Button]");
		memFormList.Add("Name:btnOpenProject");
		memFormList.Add("Position:600,390");
		memFormList.Add("Size:120,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:9.75");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Open Project");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("[Button]");
		memFormList.Add("Name:btnCreateProject");
		memFormList.Add("Position:290,390");
		memFormList.Add("Size:120,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:9.75");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Create Project");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("[ListBox]");
		memFormList.Add("Name:lstProjecs");
		memFormList.Add("Position:10,40");
		memFormList.Add("Size:708,344");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Projecs");
		memFormList.Add("BorderStyle:FixedSingle");
		memFormList.Add("BorderStyle:Outlined");

            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            // this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(Width, Height);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.Name ="pnlRecentProjects";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text ="Recent Projects";
            this.ResumeLayout(false);
            this.PerformLayout();

		cFormManager.readControlsInMem_s(Controls, this, memFormList,false);


            Console.WriteLine("Main form loaded");

            this.Click += new System.EventHandler(this.Controls_Click);
            this.DoubleClick += new System.EventHandler(this.Controls_DoubleClick);

            for (int r=0;r<Controls.Count;r++)
            {
                Controls[r].Click       += new System.EventHandler(this.Controls_Click);
                Controls[r].DoubleClick += new System.EventHandler(this.Controls_DoubleClick);
                Controls[r].KeyDown 	+= new KeyEventHandler(this.Controls_KeyDown);
                try{dCtls.Add(Controls[r].Name,Controls[r]);}catch(Exception _e){}
            }

            for (int r = 0; r < (int)efrmMainControls.COUNT; r++)
            {
                string ctlName = Enum.GetName(typeof(efrmMainControls), r);
                dCtlName.Add(ctlName, (efrmMainControls)r);
            }

			txtExistentProjectDir = (TextBox)getControl(efrmMainControls.txtExistentProjectDir);
			btnBrowse = (Button)getControl(efrmMainControls.btnBrowse);
			btnClose = (Button)getControl(efrmMainControls.btnClose);
			btnOpenProject = (Button)getControl(efrmMainControls.btnOpenProject);
			btnCreateProject = (Button)getControl(efrmMainControls.btnCreateProject);
			lstProjecs = (ListBox)getControl(efrmMainControls.lstProjecs);


        }

		public Control getControl(efrmMainControls control)
		{
			string ctlName = Enum.GetName(typeof(efrmMainControls), control);
			return dCtls[ctlName];
		}

        private efrmMainControls checkDCtlName(string ctlName)
        {
            efrmMainControls result = efrmMainControls.COUNT;

            try
            {
                result = dCtlName[ctlName];
            }
            catch(Exception _e)
            {
                result = efrmMainControls.COUNT;
            }
            return result;
        }

        private void Controls_Click(object sender, EventArgs e)
        {
            Control ctl = (Control)sender;
            Controls_Click(ctl, checkDCtlName(ctl.Name), e);
        }

        private void Controls_DoubleClick(object sender, EventArgs e)
        {
            Control ctl = (Control)sender;
            Controls_DoubleClick(ctl, checkDCtlName(ctl.Name), e);
        }
 
        private void Controls_KeyDown(object sender, KeyEventArgs e)
        {
            Control ctl = (Control)sender;
            Controls_KeyDown(ctl, checkDCtlName(ctl.Name), e);
		}

        private void Controls_Tick(object sender, EventArgs e,Control ctl)
        {
            // Controls_Tick(ctl, checkDCtlName(ctl.Name), e);
        }

        #endregion

    }
}
