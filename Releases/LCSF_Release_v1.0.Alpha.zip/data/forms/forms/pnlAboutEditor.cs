using System;
using System.Collections.Generic;
using System.Windows.Forms;
using LCSF_Editor;
using LCSF_Editor.CustomControls;

// EDITOR GENERATED CODE THIS FILE IS OVERRIDED , CUSTOM CODE RELATED TO CONTROLS , PUT in the "GUI/pnlXXXXLogic.cs"

namespace LSCFForms
{

partial class pnlAbout

    {

		public enum efrmMainControls
		{
			pnlAbout,
			lblMainTitle,
			btnOK,
			txtBTC,
			txtETH,
			lblBTC,
			lblETH,
			lblUSDT,
			txtUSDT,
			lblCafecito,
			txtCafecito,
			lblDonations,
			lblYoutubetutorials,
			txtYoutube,
			btnCopyYoutube,
			btnCopyBTC,
			btnCopyETH,
			btnCopyUSDT,
			btnCopyCafecito,
			COUNT
		};


		Button btnCopyCafecito = new Button();
		Button btnCopyUSDT = new Button();
		Button btnCopyETH = new Button();
		Button btnCopyBTC = new Button();
		Button btnCopyYoutube = new Button();
		TextBox txtYoutube = new TextBox();
		Label lblYoutubetutorials = new Label();
		Label lblDonations = new Label();
		TextBox txtCafecito = new TextBox();
		Label lblCafecito = new Label();
		TextBox txtUSDT = new TextBox();
		Label lblUSDT = new Label();
		Label lblETH = new Label();
		Label lblBTC = new Label();
		TextBox txtETH = new TextBox();
		TextBox txtBTC = new TextBox();
		Button btnOK = new Button();
		Label lblMainTitle = new Label();


		public List<string> memFormList = new List<string>();

        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private Dictionary<string, efrmMainControls> dCtlName = new Dictionary<string, efrmMainControls>();
        private Dictionary<string, Control> dCtls = new Dictionary<string, Control>();

        private void InitializeComponent()
        {
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pnlAbout));


		memFormList.Add("[Panel]");
		memFormList.Add("Name:pnlAbout");
		memFormList.Add("MaximizeBox:False");
		memFormList.Add("MinimizeBox:False");
		memFormList.Add("Size:640,510");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:About");
		memFormList.Add("[Button]");
		memFormList.Add("Name:btnCopyCafecito");
		memFormList.Add("Position:530,350");
		memFormList.Add("Size:51,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Copy");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("[Button]");
		memFormList.Add("Name:btnCopyUSDT");
		memFormList.Add("Position:530,300");
		memFormList.Add("Size:51,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Copy");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("[Button]");
		memFormList.Add("Name:btnCopyETH");
		memFormList.Add("Position:530,250");
		memFormList.Add("Size:51,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Copy");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("[Button]");
		memFormList.Add("Name:btnCopyBTC");
		memFormList.Add("Position:530,200");
		memFormList.Add("Size:51,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Copy");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("[Button]");
		memFormList.Add("Name:btnCopyYoutube");
		memFormList.Add("Position:530,120");
		memFormList.Add("Size:51,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Copy");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("[TextInput]");
		memFormList.Add("Name:txtYoutube");
		memFormList.Add("Position:50,125");
		memFormList.Add("Size:472,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Youtube");
		memFormList.Add("BorderStyle:FixedSingle");
		memFormList.Add("Multiline:False");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("TextType:Text");
		memFormList.Add("BorderStyle:Outlined");
		memFormList.Add("[Label]");
		memFormList.Add("Name:lblYoutubetutorials");
		memFormList.Add("Position:50,80");
		memFormList.Add("Size:160,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:12");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Youtube (tutorials):");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("BorderStyle:None");
		memFormList.Add("[Label]");
		memFormList.Add("Name:lblDonations");
		memFormList.Add("Position:50,160");
		memFormList.Add("Size:532,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:15");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Donations:");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("BorderStyle:None");
		memFormList.Add("[TextInput]");
		memFormList.Add("Name:txtCafecito");
		memFormList.Add("Position:140,355");
		memFormList.Add("Size:381,32");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Cafecito");
		memFormList.Add("BorderStyle:FixedSingle");
		memFormList.Add("Multiline:False");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("TextType:Text");
		memFormList.Add("BorderStyle:Outlined");
		memFormList.Add("[Label]");
		memFormList.Add("Name:lblCafecito");
		memFormList.Add("Position:50,350");
		memFormList.Add("Size:76,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:12");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:Cafecito:");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("BorderStyle:None");
		memFormList.Add("[TextInput]");
		memFormList.Add("Name:txtUSDT");
		memFormList.Add("Position:110,305");
		memFormList.Add("Size:412,32");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:USDT");
		memFormList.Add("BorderStyle:FixedSingle");
		memFormList.Add("Multiline:False");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("TextType:Text");
		memFormList.Add("BorderStyle:Outlined");
		memFormList.Add("[Label]");
		memFormList.Add("Name:lblUSDT");
		memFormList.Add("Position:50,300");
		memFormList.Add("Size:52,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:12");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:USDT:");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("BorderStyle:None");
		memFormList.Add("[Label]");
		memFormList.Add("Name:lblETH");
		memFormList.Add("Position:50,250");
		memFormList.Add("Size:52,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:12");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:ETH:");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("BorderStyle:None");
		memFormList.Add("[Label]");
		memFormList.Add("Name:lblBTC");
		memFormList.Add("Position:50,200");
		memFormList.Add("Size:52,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:12");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:BTC:");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("BorderStyle:None");
		memFormList.Add("[TextInput]");
		memFormList.Add("Name:txtETH");
		memFormList.Add("Position:110,255");
		memFormList.Add("Size:412,32");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:ETH");
		memFormList.Add("BorderStyle:FixedSingle");
		memFormList.Add("Multiline:False");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("TextType:Text");
		memFormList.Add("BorderStyle:Outlined");
		memFormList.Add("[TextInput]");
		memFormList.Add("Name:txtBTC");
		memFormList.Add("Position:110,205");
		memFormList.Add("Size:412,32");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:BTC");
		memFormList.Add("BorderStyle:FixedSingle");
		memFormList.Add("Multiline:False");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("TextType:Text");
		memFormList.Add("BorderStyle:Outlined");
		memFormList.Add("[Button]");
		memFormList.Add("Name:btnOK");
		memFormList.Add("Position:260,420");
		memFormList.Add("Size:147,42");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:11");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:OK");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("[Label]");
		memFormList.Add("Name:lblMainTitle");
		memFormList.Add("Position:50,30");
		memFormList.Add("Size:532,30");
		memFormList.Add("FontName:DejaVu Sans");
		memFormList.Add("FontSize:15");
		memFormList.Add("BackColor:100,100,100");
		memFormList.Add("ForeColor:211,211,211");
		memFormList.Add("Text:MainTitle");
		memFormList.Add("FlatStyle:Flat");
		memFormList.Add("TextAlign:Left");
		memFormList.Add("BorderStyle:None");

            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            // this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(Width, Height);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.Name ="pnlAbout";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text ="About";
            this.ResumeLayout(false);
            this.PerformLayout();

		cFormManager.readControlsInMem_s(Controls, this, memFormList,false);


            Console.WriteLine("Main form loaded");

            this.Click += new System.EventHandler(this.Controls_Click);
            this.DoubleClick += new System.EventHandler(this.Controls_DoubleClick);

            for (int r=0;r<Controls.Count;r++)
            {
                Controls[r].Click       += new System.EventHandler(this.Controls_Click);
                Controls[r].DoubleClick += new System.EventHandler(this.Controls_DoubleClick);
                Controls[r].KeyDown 	+= new KeyEventHandler(this.Controls_KeyDown);
                try{dCtls.Add(Controls[r].Name,Controls[r]);}catch(Exception _e){}
            }

            for (int r = 0; r < (int)efrmMainControls.COUNT; r++)
            {
                string ctlName = Enum.GetName(typeof(efrmMainControls), r);
                dCtlName.Add(ctlName, (efrmMainControls)r);
            }

			btnCopyCafecito = (Button)getControl(efrmMainControls.btnCopyCafecito);
			btnCopyUSDT = (Button)getControl(efrmMainControls.btnCopyUSDT);
			btnCopyETH = (Button)getControl(efrmMainControls.btnCopyETH);
			btnCopyBTC = (Button)getControl(efrmMainControls.btnCopyBTC);
			btnCopyYoutube = (Button)getControl(efrmMainControls.btnCopyYoutube);
			txtYoutube = (TextBox)getControl(efrmMainControls.txtYoutube);
			lblYoutubetutorials = (Label)getControl(efrmMainControls.lblYoutubetutorials);
			lblDonations = (Label)getControl(efrmMainControls.lblDonations);
			txtCafecito = (TextBox)getControl(efrmMainControls.txtCafecito);
			lblCafecito = (Label)getControl(efrmMainControls.lblCafecito);
			txtUSDT = (TextBox)getControl(efrmMainControls.txtUSDT);
			lblUSDT = (Label)getControl(efrmMainControls.lblUSDT);
			lblETH = (Label)getControl(efrmMainControls.lblETH);
			lblBTC = (Label)getControl(efrmMainControls.lblBTC);
			txtETH = (TextBox)getControl(efrmMainControls.txtETH);
			txtBTC = (TextBox)getControl(efrmMainControls.txtBTC);
			btnOK = (Button)getControl(efrmMainControls.btnOK);
			lblMainTitle = (Label)getControl(efrmMainControls.lblMainTitle);


        }

		public Control getControl(efrmMainControls control)
		{
			string ctlName = Enum.GetName(typeof(efrmMainControls), control);
			return dCtls[ctlName];
		}

        private efrmMainControls checkDCtlName(string ctlName)
        {
            efrmMainControls result = efrmMainControls.COUNT;

            try
            {
                result = dCtlName[ctlName];
            }
            catch(Exception _e)
            {
                result = efrmMainControls.COUNT;
            }
            return result;
        }

        private void Controls_Click(object sender, EventArgs e)
        {
            Control ctl = (Control)sender;
            Controls_Click(ctl, checkDCtlName(ctl.Name), e);
        }

        private void Controls_DoubleClick(object sender, EventArgs e)
        {
            Control ctl = (Control)sender;
            Controls_DoubleClick(ctl, checkDCtlName(ctl.Name), e);
        }
 
        private void Controls_KeyDown(object sender, KeyEventArgs e)
        {
            Control ctl = (Control)sender;
            Controls_KeyDown(ctl, checkDCtlName(ctl.Name), e);
		}

        private void Controls_Tick(object sender, EventArgs e,Control ctl)
        {
            Controls_Tick(ctl, checkDCtlName(ctl.Name), e);
        }

        #endregion

    }
}
