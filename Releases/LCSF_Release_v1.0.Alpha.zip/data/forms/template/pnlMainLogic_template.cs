﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LSCFForms
{

[FRM_CLASS_NAME]
    {

[FRM_CLASS_NAME_CONSTRUCTOR]
        {
            InitializeComponent();
        }

[ENUM-CLICK-CASE]       // private void Controls_Click(Control sender, efrmMainControls ctlName, EventArgs e)

[ENUM-DOUBLECLICK-CASE] // private void Controls_DoubleClick(Control sender, efrmMainControls ctlName, EventArgs e)

[ENUM-KEYDOWN-CASE]     // private void Controls_KeyDown(Control sender, efrmMainControls ctlName, KeyEventArgs e)

[ENUM-TICK-CASE]        // private void Controls_TICK(Control sender, efrmMainControls ctlName)

    }
}
