using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LSCFForms
{

    public partial class pnlRecentProjects : Form
    {

		public pnlRecentProjects()
        {
            InitializeComponent();
        }

		private void Controls_Click(Control sender, efrmMainControls ctlName, EventArgs e)
		{
			switch(ctlName)
			{
				case efrmMainControls.lstProjecs:
				{
				}
				break;
				case efrmMainControls.btnCreateProject:
				{
				}
				break;
				case efrmMainControls.btnOpenProject:
				{
				}
				break;
				case efrmMainControls.btnExit:
				{
				}
				break;
				case efrmMainControls.btnBrowse:
				{
				}
				break;
			}
		}


		private void Controls_DoubleClick(Control sender, efrmMainControls ctlName, EventArgs e)
		{
			switch(ctlName)
			{
			}
		}


		private void Controls_KeyDown(Control sender, efrmMainControls ctlName, KeyEventArgs e)
		{
			switch(ctlName)
			{
				case efrmMainControls.lstProjecs:
				{
				}
				break;
				case efrmMainControls.txtExistentProjectDir:
				{
				}
				break;
			}
		}


		private void Controls_Tick(Control sender, efrmMainControls ctlName, EventArgs e)
		{
			switch(ctlName)
			{
			}
		}


    }
}
